/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   defaultArguments.cpp
 * Author: manish
 *
 * Created on 21 September, 2020, 10:00 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

class DefaultArguments{
    float a,b,c,d,e;
public:
    float result(float a,float b,float c, float d,float e,int noOfSub=5){
        return (a+b+c+d+e)/noOfSub;
    }
    void printline(char ch='*',int len=40){
        int i;
        for(i=0;i<=len;i++){
            cout<<ch;
        }
    }
    float getNumbers(void){
//        float a,b,c,d,e;
        
        cout<<"Enter the marks of 1st subject : ";
        cin>>a;
        cout<<"\nEnter the marks of 2nd subject : ";
        cin>>b;
        cout<<"\nEnter the marks of 3rd subject : ";
        cin>>c;
        cout<<"\nEnter the marks of 4th subject : ";
        cin>>d;
        cout<<"\nEnter the marks of 5th subject : ";
        cin>>e;
        
    }
    void output(void){
        this->getNumbers();
        this->printline(); //calling fn with both default arguments
        cout<<"\nMarks in percentage : "<<this->result(a,b,c,d,e,4)<<"%\n";
        this->printline('=');   //calling fn with one default arguments
    }
};
//int main(int argc, char** argv) {
//    DefaultArguments df;
//    df.output();
//    return 0;
//}

