/*
 * Function Template with two generic types
 * 332
 */

/* 
 * File:   templateFunction.cpp
 * Author: manish
 *
 * Created on 24 September, 2020, 4:58 PM
 */

//#include <cstdlib>
#include<iostream>
#define ArrMax 5

using namespace std;


template <class T> 
T find_min(T arr[])
{
    int i;
    T min = arr[0];
    for(i=1; i < ArrMax ; i++)
    if(arr[i]<min)
            min=arr[i];
    return (min);
   
} 

//int main() {
//   int arri[5] = {5,4,9,6,7};
//   float arrf[5] = {-9.9,12.2,3.1,9.9,8.9};
//   char arrc[5] = {'a','A','/','4','~'};
//   
//    cout<<"Minimum value in integer array = "<<find_min(arri);
//    cout<<"\nMinimum value in float array = "<<find_min(arrf);
//    cout<<"\nMinimum value (as per SSCII) in character array = "<<find_min(arrc);
//    return 0;
//}

