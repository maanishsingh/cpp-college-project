/*
 * Implementation of Destructor
 */

/* 
 * File:   Destructors.cpp
 * Author: manish
 *
 * Created on 22 September, 2020, 10:49 PM
 */

//#include <cstdlib>
#include<iostream>

using namespace std;

class Destructors{
   static int count;
public:
    Destructors(){
        count ++;
        cout<<"\nConstructor Msg : Object number "<<count<<" created...";
        
    }
    ~Destructors(){
        cout<<"\nDestructor Msg : Object number "<<count<<" destroyed ...";
        count --;
    }
};
int Destructors::count;
//int main() {
//    Destructors d;
//    {
//        cout<<"\nInside Main Inner Block Object 2 and 3 going to create";
//        Destructors d2,d3;
//    }
//
//    return 0;
//}

