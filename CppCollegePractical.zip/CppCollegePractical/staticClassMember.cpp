/*
 * Static Class Member
 * 105
 */

/* 
 * File:   staticClassMember.cpp
 * Author: manish
 *
 * Created on 22 September, 2020, 12:25 AM
 */

//#include <cstdlib>
#include <iostream>

using namespace std;

class StaticClassMember{
    static int count;
    int a;
public:
    
    
    void setData(int a){
        this->a = a;
        count ++;
    }
    void showData(void){
        cout<<"\nValue of count : "<< count;
    }
};
int StaticClassMember::count;
//int main() {
//    StaticClassMember a,b,c; //count is initialized to zero
//    
//    cout<<"displaying count before reading data";
//    a.showData();
//    b.showData();
//    c.showData();
//    
//    a.setData(40);
//    b.setData(41);
//    c.setData(42);
//    
//    cout<<"\ndisplaying count after reading data";
//    a.showData();
//    b.showData();
//    c.showData(); 
//
//    return 0;
//}

