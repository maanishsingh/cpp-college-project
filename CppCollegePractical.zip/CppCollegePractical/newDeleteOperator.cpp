/*
 * Use of new and Delete Operator
 * With the help of new operator dynamically memory is allocated
 * With delete operator that memory is released 
 */

/* 
 * File:   newDeleteOperator.cpp
 * Author: manish
 *
 * Created on 21 September, 2020, 4:21 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

class NewDelete{
    
    int *arr;
    int size;
    
public:
    int setvalue(void);
    int deleteObject(void);
    

};

int NewDelete::setvalue(void){
    cout<<"Enter Size of integer array : ";
    cin>>size;
    arr = new int[size];
    cout<<"\nArray created with size "<<size;
    cout<<"\nDynamic allocation of memory for array is successful.";
    return 0;
}

int NewDelete::deleteObject(void){
    delete arr;
    cout<<"\n Array deleted";
    return 0;
}

/*
 * 
 */
//int main(int argc, char** argv) {
//    NewDelete nd;
//    nd.setvalue();
//    nd.deleteObject();
//    return 0;
//}

