/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   arraysOfObject.cpp
 * Author: manish
 *
 * Created on 22 September, 2020, 1:56 AM
 */

//#include <cstdlib>
#include <iostream>

using namespace std;

class ArraysOfObject{
    char name[30];
    float age;
public:
    void setData(void){
        cout<<"Enter Name : ";
        cin>>name;
        cout<<"Enter Age : ";
        cin>>age;
    }
    void getData(void){
        cout<<"Name : "<<name<<"\n";
        cout<<"Age : "<<age<<"\n";
    }
};
const int size=2;
//int main() {
//    int i;
//    ArraysOfObject ao[size];
//    for(i=0;i<=size;i++){
//        cout<<"\nEnter Details of Managers "<<i+1<<"\n";
//        ao[i].setData();
//        
//    }
//    cout<<"************************";
//    for(i=0;i<=size;i++){
//        cout<<"\nDetails of Managers "<<i+1<<"\n";
//        ao[i].getData();
//        
//    }
//    return 0;
//}

