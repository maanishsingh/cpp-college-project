/*
 * Overloading Unary operators
 * Overloading Unary Minus
 */

/* 
 * File:   overloadingMinus.cpp
 * Author: manish
 *
 * Created on 22 September, 2020, 11:39 PM
 */
//
//#include <cstdlib>
#include <iostream>
using namespace std;

class OverloadingUM{
    int x,y,z;
public:
    void setData(int a,int b, int c){
        x=a;
        y=b;
        z= c;
    }
    void getData(){
        cout<<"x = "<<x;
        cout<<"\ny = "<<y;
        cout<<"\nz = "<<z;
    }
    void operator-(){
        x=-x;
        y=-y;
        z= -z;
    }
};

//int main() {
//    cout<<"Before Using Overloaded Operator\n";
//    OverloadingUM u;
//    u.setData(10,-20,30);
//    u.getData();
//    
//    -u;
//    cout<<"\nAfter Using Overloaded Operator\n";
//    u.getData();
//
//    return 0;
//}

