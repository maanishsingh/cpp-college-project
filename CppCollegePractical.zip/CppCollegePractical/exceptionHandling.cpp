/*
 * Try Block Throwing an Exception
 * 344
 */

/* 
 * File:   exceptionHandling.cpp
 * Author: manish
 *
 * Created on 23 September, 2020, 12:30 AM
 */
//
//#include <cstdlib>
#include <iostream>

using namespace std;

class ExceptionHandling{
    int x,y,z;
public:
    ExceptionHandling(int a, int b){
        x=a;
        y=b;
        z=x-y;
        tryCatch();
    }
   void tryCatch(){
        try{
            if(z!=0){
                cout<<"Result (a/z) = "<<x/z;
            }else{
                throw(z);
            }
        }catch(int i){
            cout<<"\nException caught : divide by "<<i;
        }
    }
};

//int main() {
////    ExceptionHandling eh(20,15);        //no exception
//    ExceptionHandling eh1(10,10);       //Exception zero
//    return 0;
//}

