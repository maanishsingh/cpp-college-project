/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   multipleInheritance.cpp
 * Author: manish
 *
 * Created on 23 September, 2020, 4:46 PM
 */
//
//#include <cstdlib>
#include<iostream>

using namespace std;

class M{
protected:
    int m;
public:
    void set_m(int a){
        m=a;
    }
};

class N{
protected:
    int n;
public:
    void set_n(int a){
        n=a;
    }
};

class P : public M, public N{
public:
    void display(){
        cout<<"m = "<<m<<"\n";
        cout<<"n = "<<n<<"\n";
        cout<<"m X n = "<<m*n<<"\n";
    }
};
//int main() {
//    P p;
//    p.set_m(10);
//    p.set_n(20);
//    p.display();
//
//    return 0;
//}

