/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   inlineFunction.cpp
 * Author: manish
 *
 * Created on 21 September, 2020, 9:39 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

class InlineFunction{
public:
    inline float multiply(float x, float y){return x*y;}
    inline double division(double x, double y){return x/y;}
};

//int main(int argc, char** argv) {
//    InlineFunction m;
//    cout<<"Product of two number is : "<<m.multiply(2,4);
//    cout<<"\nResult of multiplication is :"<<m.division(8,2);
//
//    return 0;
//}

