/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   useOfMathFunctions.cpp
 * Author: manish
 *
 * Created on 22 September, 2020, 12:04 AM
 */

#include <cstdlib>
#include <iostream>
#include <math.h>
using namespace std;

class MathFunction{
    float a;
public:
    void getValue(void){
        cout<<"Enter any Number : ";
        cin>>a;
    }
    void showValue(void){
        cout<<"Sin "<<a<<" = "<<sin(a)<<'\n';
        cout<<"Cos "<<a<<" = "<<cos(a)<<'\n';
        cout<<"tan "<<a<<" = "<<tan(a)<<'\n';
        cout<<"Cos "<<a<<" = "<<cos(a)<<'\n';
        cout<<"log10 of "<<a<<" = "<<log10(a)<<'\n';
        cout<<"square root of "<<a<<" = "<<sqrt(a)<<'\n';
    }
    
};
//
//int main(int argc, char** argv) {
//    MathFunction mf;
//    mf.getValue();
//    mf.showValue();
//
//    return 0;
//}

