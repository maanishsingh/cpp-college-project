/*
 * Example of Parameterized Constructor
 * 131
 */

/* 
 * File:   parameterizedConstructor.cpp
 * Author: manish
 *
 * Created on 22 September, 2020, 10:09 PM
 */

//#include <cstdlib>
#include <iostream>

using namespace std;

class Point{
    int x,y;
    static int n;
public:
    Point(int a, int b){    //constructor with parameters
        x=a;
        y=b;
        n++;
    }
    void getData(void){
        cout<<"Point "<<n<<" = ("<<x<<","<<y<<")\n";
    }
};
int Point::n;

//int main() {
//    Point p(1,1);
//    p.getData();
//    
//    Point p2(5,10);
//    p2.getData();
//
//    return 0;
//}

