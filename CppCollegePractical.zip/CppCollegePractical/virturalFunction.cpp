/*
 * Virtual Function
 * 246
 */

/* 
 * File:   virturalFunction.cpp
 * Author: manish
 *
 * Created on 23 September, 2020, 10:57 PM
 */

//#include <cstdlib>
#include <iostream>

using namespace std;

class Base{
public:
    void display(){cout<<"\n Display Base";}
    virtual void show(){cout<<"\n Show Base";}
};

class Derived : public Base{
public:
    void display(){cout<<"\n Display Derived";}
    void show(){cout<<"\n show Derived";}
};

//int main() {
//    Base b;
//    Derived d;
//    
//    Base *bptr;
//    cout<<"\nbptr point to Base\n";
//    bptr = &b;
//    bptr->display();
//    bptr->show();
//    
//    cout<<"\n\nbptr point to Derived\n";
//    bptr = &d;
//    bptr->display();
//    bptr->show();
//
//    return 0;
//}

