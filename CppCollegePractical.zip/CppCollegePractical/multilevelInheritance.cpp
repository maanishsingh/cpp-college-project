/*
 * Multilevel Inheritance
 * 193
 */

/* 
 * File:   multilevelInheritance.cpp
 * Author: manish
 *
 * Created on 23 September, 2020, 3:49 PM
 */

//#include <cstdlib>
#include<iostream>

using namespace std;

class Student{
protected:
    int roll_no;
public:
    void setRollNo(int a){
        roll_no= a;
    }
    void getRollNo(){
        cout<<"Roll No : "<<roll_no<<"\n";
    }
};

class Test : public Student{
protected:
    float sub1,sub2;
public:
    void setMarks(float a, float b){
        sub1 = a;
        sub2 = b;
    }
    void getMarks(){
        cout<<"Marks in SUB1 = "<<sub1<<"\n";
        cout<<"Marks in SUB2 = "<<sub2<<"\n";
        
    }
};

class Result : public Test{
    float total;
public:
    void getResults(){
        total = sub1+sub2;
        getRollNo();
        getMarks();
        cout<<"Total = "<<total<<"\n";
    }
    
};

//int main() {
//    Result r;
//    r.setRollNo(111);
//    r.setMarks(75,95.5);
//    r.getResults();
//
//    return 0;
//}

