/*
 * class person having no constructor 
 * All functions are declared outside of class
 * All the functions of the class are calling by the object
 * 23
 */

/* 
 * File:   UseOfClass.cpp
 * Author: manish
 *
 * Created on 21 September, 2020, 3:10 PM
 */

//#include <cstdlib>
#include <iostream>


using namespace std;

class Person{
    char name[30];
    int age;
    
public:
    void getdata(void);
    void display(void);
};
void Person :: getdata(void){
    cout<<"Enter your Name : ";
    cin>>name;
    cout<<"Enter you age : ";
    cin>>age;
    
}
void Person::display(void){
    cout<<"\nYour name is : "<<name;
    cout<<"\nYour Age is : "<<age;
    
}

//int main() {
//    Person p;
//    p.getdata();
//    p.display();
//
//    return 0;
//}