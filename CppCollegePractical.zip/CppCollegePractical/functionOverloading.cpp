/*
 * Function Overloading
 * 81
 */

/* 
 * File:   functionOverloading.cpp
 * Author: manish
 *
 * Created on 21 September, 2020, 11:42 PM
 */

//#include <cstdlib>
#include <iostream>

using namespace std;

class FunctionOverloading{
public:
    void area(int side){
        cout<<"\nArea of Square = "<<side*side;
    }
    void area(int l,int b){
        cout<<"\nArea of Rectangle = "<<l*b;
    }
    void area(float r){
        cout<<"\nArea of Circle = "<<3.14*r*r;
    }
};
//int main() {
//    FunctionOverloading fo;
//    fo.area(42);
//    fo.area(12,5);
//    fo.area(float(12.5));
//            
//    return 0;
//}

