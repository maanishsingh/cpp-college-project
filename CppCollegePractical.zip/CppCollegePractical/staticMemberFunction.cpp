/*
 * Static Member Function
 */

/* 
 * File:   staticMemberFunction.cpp
 * Author: manish
 *
 * Created on 22 September, 2020, 1:02 AM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

class StaticMemberFunction{
    int code;
    static int count;           //static member variable
public:
    void setCode(void){
        code = ++count;
    }
    void getCode(void){
        cout<<"Object number : "<<code<<"\n";
    }
    static void getCount(void){
        cout<<"count : "<<count<<"\n";
    }
    
};
int StaticMemberFunction::count;

//int main(int argc, char** argv) {
//    StaticMemberFunction t1,t2;
//    t1.setCode();
//    t2.setCode();
//    
//    StaticMemberFunction::getCount();
//    
//    StaticMemberFunction t3;
//    t3.setCode();
//    StaticMemberFunction::getCount();
//    
//    t1.getCode();
//    t2.getCode();
//    t3.getCode();
//    
//    return 0;
//}

